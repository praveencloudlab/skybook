package com.skybook.praveen.flightservice.service;

import com.skybook.praveen.flightservice.dto.request.CreateFlightRequest;
import com.skybook.praveen.flightservice.dto.request.UpdateFlightRequest;
import com.skybook.praveen.flightservice.dto.response.FlightResponse;
import com.skybook.praveen.flightservice.enums.FlightStatus;

import java.time.LocalDate;
import java.util.List;

public interface FlightService {

    List<FlightResponse> getAllFlights();

    FlightResponse updateFlight(
            Long id,
            UpdateFlightRequest request
    );

    FlightResponse createFlight(CreateFlightRequest request);
    FlightResponse updateFlightStatus(Long id, FlightStatus status);

    FlightResponse getFlightById(Long id);
    List<FlightResponse> createFlights(List<CreateFlightRequest> requests);

    List<FlightResponse> searchFlights(
            String originAirportCode,
            String destinationAirportCode,
            LocalDate departureDate);

}