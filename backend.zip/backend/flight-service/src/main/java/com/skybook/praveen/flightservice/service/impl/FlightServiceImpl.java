package com.skybook.praveen.flightservice.service.impl;

import com.skybook.praveen.flightservice.dto.request.CreateFlightRequest;
import com.skybook.praveen.flightservice.dto.request.UpdateFlightRequest;
import com.skybook.praveen.flightservice.dto.response.FlightResponse;
import com.skybook.praveen.flightservice.entity.Flight;
import com.skybook.praveen.flightservice.enums.FlightStatus;
import com.skybook.praveen.flightservice.exception.FlightNotFoundException;
import com.skybook.praveen.flightservice.mapper.FlightMapper;
import com.skybook.praveen.flightservice.repository.FlightRepository;
import com.skybook.praveen.flightservice.service.FlightService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class FlightServiceImpl implements FlightService {

    private final FlightRepository flightRepository;

    @Override
    public FlightResponse createFlight(CreateFlightRequest request) {
        validateFlightCreation(request);

        Flight flight = FlightMapper.toEntity(request);
        Flight savedFlight = flightRepository.save(flight);

        return FlightMapper.toResponse(savedFlight);
    }

    @Override
    public FlightResponse updateFlightStatus(Long id, FlightStatus status) {

        Flight flight = flightRepository.findById(id)
                .orElseThrow(() -> new FlightNotFoundException(id));

        flight.setStatus(status);

        Flight updatedFlight = flightRepository.save(flight);

        return FlightMapper.toResponse(updatedFlight);
    }
    @Override
    public List<FlightResponse> createFlights(List<CreateFlightRequest> requests) {
        List<Flight> flights = requests.stream()
                .map(FlightMapper::toEntity)
                .toList();

        List<Flight> savedFlights = flightRepository.saveAll(flights);

        return savedFlights.stream()
                .map(FlightMapper::toResponse)
                .toList();
    }
    @Override
    public FlightResponse getFlightById(Long id) {
        Flight flight = flightRepository.findById(id)
                .orElseThrow(() -> new FlightNotFoundException(id));
        return FlightMapper.toResponse(flight);
    }

    @Override
    public List<FlightResponse> searchFlights(
            String originAirportCode,
            String destinationAirportCode,
            LocalDate departureDate) {

        LocalDateTime startOfDay = departureDate.atStartOfDay();
        LocalDateTime endOfDay = departureDate.plusDays(1).atStartOfDay().minusNanos(1);

        return flightRepository
                .findByOriginAirportCodeAndDestinationAirportCodeAndDepartureTimeBetween(
                        originAirportCode.toUpperCase(),
                        destinationAirportCode.toUpperCase(),
                        startOfDay,
                        endOfDay
                )
                .stream()
                .map(FlightMapper::toResponse)
                .toList();
    }

    private void validateFlightCreation(CreateFlightRequest request) {
        if (flightRepository.existsByFlightNumber(request.flightNumber().toUpperCase())) {
            throw new IllegalArgumentException("Flight number already exists: " + request.flightNumber());
        }

        if (!request.arrivalTime().isAfter(request.departureTime())) {
            throw new IllegalArgumentException("Arrival time must be after departure time");
        }

        if (request.originAirportCode().equalsIgnoreCase(request.destinationAirportCode())) {
            throw new IllegalArgumentException("Origin and destination airports must be different");
        }
    }

    @Override
    public List<FlightResponse> getAllFlights() {

        return flightRepository.findAll()
                .stream()
                .map(FlightMapper::toResponse)
                .toList();
    }

    @Override
    public FlightResponse updateFlight(
            Long id,
            UpdateFlightRequest request) {

        Flight flight = flightRepository.findById(id)
                .orElseThrow(() -> new FlightNotFoundException(id));

        if (!flight.getFlightNumber().equalsIgnoreCase(request.airlineCode())) {
            // no-op
        }

        if (!request.arrivalTime().isAfter(request.departureTime())) {
            throw new IllegalArgumentException(
                    "Arrival time must be after departure time");
        }

        if (request.originAirportCode()
                .equalsIgnoreCase(request.destinationAirportCode())) {

            throw new IllegalArgumentException(
                    "Origin and destination airports must be different");
        }

        FlightMapper.updateEntity(flight, request);

        Flight updated = flightRepository.save(flight);

        return FlightMapper.toResponse(updated);
    }
}